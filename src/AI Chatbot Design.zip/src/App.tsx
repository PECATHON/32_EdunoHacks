import { useState, useRef, useEffect } from "react";
import { Bot, Sparkles } from "lucide-react";
import { ChatMessage, Message } from "./components/ChatMessage";
import { ChatInput } from "./components/ChatInput";
import { LoadingTimer } from "./components/LoadingTimer";
import { TableData } from "./components/TablePreview";
import { ThemeToggle } from "./components/ThemeToggle";

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "ai",
      content: "Hello! I'm your AI assistant. Upload images, documents, PDFs (even multiple at once for batch processing), or send me text, and I'll provide a summary. I can also extract tables from PDFs and CSVs!",
      timestamp: new Date(),
    },
  ]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStartTime, setProcessingStartTime] = useState<Date | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Mock table data generator for PDFs and CSV files
  const generateMockTableData = (fileName: string): TableData | undefined => {
    const lowerName = fileName.toLowerCase();
    if (lowerName.includes("pdf") || lowerName.includes("csv") || lowerName.includes("xls")) {
      return {
        headers: ["Product", "Quantity", "Price", "Total", "Status"],
        rows: [
          ["Laptop", "5", "$999.00", "$4,995.00", "In Stock"],
          ["Mouse", "50", "$29.99", "$1,499.50", "In Stock"],
          ["Keyboard", "30", "$79.99", "$2,399.70", "Low Stock"],
          ["Monitor", "15", "$299.99", "$4,499.85", "In Stock"],
          ["Webcam", "25", "$89.99", "$2,249.75", "In Stock"],
        ],
      };
    }
    return undefined;
  };

  const generateSummary = (text: string, file: File | null, files: File[] | null): string => {
    if (files && files.length > 1) {
      const pdfCount = files.filter(f => f.type === "application/pdf").length;
      const imageCount = files.filter(f => f.type.startsWith("image/")).length;
      const otherCount = files.length - pdfCount - imageCount;

      return `📦 Batch Processing Summary:\n\nProcessed ${files.length} files:\n• ${pdfCount} PDF document(s)\n• ${imageCount} image(s)\n• ${otherCount} other file(s)\n\nTotal size: ${(files.reduce((acc, f) => acc + f.size, 0) / 1024).toFixed(1)} KB\n\nKey Findings:\n• All files have been successfully processed\n• Text content extracted and analyzed from documents\n• Images analyzed for visual content\n• Tables detected and extracted where applicable\n\nBatch processing complete! All summaries have been consolidated above.\n\nNote: This is a mock summary. In production, each file would be individually analyzed and results would be aggregated.`;
    }

    if (file) {
      const fileType = file.type;
      if (fileType.startsWith("image/")) {
        return `📊 Image Analysis Summary:\n\nI've analyzed the image "${file.name}". This appears to be a ${fileType.split("/")[1].toUpperCase()} image file.\n\nKey observations:\n• File size: ${(file.size / 1024).toFixed(1)} KB\n• The image has been successfully processed\n• Visual content appears clear and well-structured\n\nNote: This is a mock summary. In a production environment, actual AI image recognition would provide detailed analysis of the image contents, objects, text, and context.`;
      } else if (fileType === "application/pdf") {
        return `📄 PDF Document Summary:\n\nDocument: "${file.name}"\n\nSummary:\n• Total size: ${(file.size / 1024).toFixed(1)} KB\n• Document type: PDF\n• Successfully processed\n• Table data extracted (see below)\n\nKey Points:\n• The document has been analyzed for structure and content\n• Main topics and themes have been identified\n• Important sections and headings noted\n• Tabular data has been extracted and is displayed below\n\nNote: This is a mock summary. A real implementation would extract and analyze the actual text content from the PDF.`;
      } else if (fileType === "text/csv" || file.name.endsWith(".csv")) {
        return `📊 CSV File Summary:\n\nFile: "${file.name}"\n\nAnalysis:\n• File type: CSV\n• Size: ${(file.size / 1024).toFixed(1)} KB\n• Processing status: Complete\n\nData Overview:\n• CSV data has been parsed successfully\n• Table structure identified\n• All rows and columns extracted\n• Data is displayed in the table below\n\nYou can download the extracted data using the button below the table.\n\nNote: This is a mock summary. In production, the actual CSV content would be parsed and displayed.`;
      } else {
        return `📎 Document Summary:\n\nDocument: "${file.name}"\n\nAnalysis:\n• File type: ${fileType}\n• Size: ${(file.size / 1024).toFixed(1)} KB\n• Processing status: Complete\n\nContent Overview:\n• The document has been processed successfully\n• Text content extracted and analyzed\n• Key information identified\n\nNote: This is a mock summary. In production, the actual document content would be extracted and summarized.`;
      }
    } else if (text) {
      const wordCount = text.split(/\s+/).length;
      return `📝 Text Summary:\n\nOriginal length: ${wordCount} words\n\nKey Points:\n• Your message has been analyzed\n• Main themes and topics identified\n• Sentiment: Neutral to Positive\n\nSummary:\nYou've shared a message containing ${wordCount} words. The text has been processed and the main ideas have been extracted.\n\nNote: This is a mock summary. A real AI would provide detailed insights, key takeaways, and condensed versions of longer texts.`;
    }
    return "I'm ready to help! Please send me text or upload a file to summarize.";
  };

  const handleSendMessage = async (text: string, file: File | null, files?: File[]) => {
    if (!text.trim() && !file && (!files || files.length === 0)) return;

    const filesToProcess = files || (file ? [file] : []);
    const isBatch = filesToProcess.length > 1;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: text || (isBatch ? `Please analyze these ${filesToProcess.length} files` : "Please summarize this file"),
      file: file
        ? {
            name: file.name,
            type: file.type,
            url: file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined,
          }
        : undefined,
      files: isBatch
        ? filesToProcess.map(f => ({
            name: f.name,
            type: f.type,
            url: f.type.startsWith("image/") ? URL.createObjectURL(f) : undefined,
          }))
        : undefined,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsProcessing(true);
    setProcessingStartTime(new Date());

    // Simulate AI processing time (longer for batch processing)
    const processingTime = isBatch ? 3000 + (filesToProcess.length * 500) : 2000;
    
    setTimeout(() => {
      const fileForTable = file || (filesToProcess.length > 0 ? filesToProcess[0] : null);
      const tableData = fileForTable ? generateMockTableData(fileForTable.name) : undefined;

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: "ai",
        content: generateSummary(text, file, isBatch ? filesToProcess : null),
        tableData: tableData,
        file: file
          ? {
              name: file.name,
              type: file.type,
            }
          : undefined,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, aiResponse]);
      setIsProcessing(false);
      setProcessingStartTime(null);
    }, processingTime);
  };

  const handleRecheck = (messageId: string, errorDescription: string) => {
    // Mark message as rechecking
    setMessages((prev) =>
      prev.map((msg) =>
        msg.id === messageId ? { ...msg, isRechecking: true } : msg
      )
    );

    // Simulate recheck processing
    setTimeout(() => {
      setMessages((prev) => {
        const messageIndex = prev.findIndex((msg) => msg.id === messageId);
        if (messageIndex === -1) return prev;

        const originalMessage = prev[messageIndex];
        const updatedMessage = {
          ...originalMessage,
          content: `🔄 Rechecked Summary (Error Addressed):\n\n${errorDescription}\n\n✅ Updated Analysis:\n\n${originalMessage.content}\n\n--- Additional Review ---\nBased on your feedback, I've re-analyzed the content with special attention to:\n• Data accuracy and completeness\n• Table structure and column alignment\n• Missing information or gaps\n• Overall quality of extraction\n\nThe summary has been refined to address the issues you reported.`,
          isRechecking: false,
          tableData: originalMessage.tableData
            ? {
                ...originalMessage.tableData,
                rows: [
                  ...originalMessage.tableData.rows,
                  ["Updated Row", "100", "$149.99", "$14,999.00", "New"],
                ],
              }
            : originalMessage.tableData,
        };

        return [
          ...prev.slice(0, messageIndex),
          updatedMessage,
          ...prev.slice(messageIndex + 1),
        ];
      });
    }, 2500);
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 sunset:from-[oklch(0.12_0.06_250)] sunset:to-[oklch(0.18_0.08_240)]">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 sunset:bg-[oklch(0.18_0.06_245)] border-b border-border shadow-sm p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-600 to-indigo-600 sunset:from-orange-500 sunset:to-pink-600 p-2 rounded-xl">
              <Bot className="size-6 text-white" />
            </div>
            <div>
              <h1 className="flex items-center gap-2">
                AI Document Summarizer
                <Sparkles className="size-4 text-yellow-500 sunset:text-orange-400" />
              </h1>
              <p className="text-sm text-gray-500 dark:text-gray-400 sunset:text-[oklch(0.65_0.05_50)]">
                Upload files or send text for instant AI summaries • Batch processing • Table extraction
              </p>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto p-4">
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} onRecheck={handleRecheck} />
          ))}
          {isProcessing && processingStartTime && (
            <div className="flex justify-start mb-4">
              <div className="bg-gray-100 dark:bg-gray-800 sunset:bg-[oklch(0.2_0.06_245)] rounded-2xl px-4 py-3">
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 sunset:bg-orange-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 sunset:bg-orange-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                      <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 sunset:bg-orange-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                    </div>
                    <span className="text-gray-600 dark:text-gray-300 sunset:text-[oklch(0.95_0.02_60)]">Analyzing and extracting data...</span>
                  </div>
                  <LoadingTimer startTime={processingStartTime} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="max-w-4xl mx-auto w-full">
        <ChatInput onSendMessage={handleSendMessage} disabled={isProcessing} />
      </div>
    </div>
  );
}