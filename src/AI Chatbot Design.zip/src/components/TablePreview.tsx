import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Download } from "lucide-react";
import { Button } from "./ui/button";

export interface TableData {
  headers: string[];
  rows: string[][];
}

interface TablePreviewProps {
  data: TableData;
  fileName?: string;
}

export function TablePreview({ data, fileName }: TablePreviewProps) {
  const handleDownloadCSV = () => {
    const csv = [
      data.headers.join(","),
      ...data.rows.map((row) => row.join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName || "extracted-data.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="my-3 border border-border rounded-lg bg-white dark:bg-gray-800 sunset:bg-[oklch(0.22_0.07_245)] overflow-hidden">
      <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 sunset:bg-[oklch(0.25_0.08_240)] border-b border-border">
        <div>
          <h4>Extracted Table Data</h4>
          <p className="text-sm text-gray-600 dark:text-gray-400 sunset:text-[oklch(0.65_0.05_50)]">
            {data.rows.length} rows × {data.headers.length} columns
          </p>
        </div>
        <Button onClick={handleDownloadCSV} size="sm" variant="outline">
          <Download className="size-4 mr-2" />
          Download CSV
        </Button>
      </div>
      <div className="overflow-x-auto max-h-96">
        <Table>
          <TableHeader>
            <TableRow>
              {data.headers.map((header, index) => (
                <TableHead key={index} className="whitespace-nowrap">
                  {header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.rows.map((row, rowIndex) => (
              <TableRow key={rowIndex}>
                {row.map((cell, cellIndex) => (
                  <TableCell key={cellIndex} className="whitespace-nowrap">
                    {cell}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}