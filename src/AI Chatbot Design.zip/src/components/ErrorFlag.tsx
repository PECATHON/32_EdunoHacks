import { useState } from "react";
import { Flag, RefreshCw, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";

interface ErrorFlagProps {
  messageId: string;
  onRecheck: (messageId: string, errorDescription: string) => void;
  isRechecking?: boolean;
}

export function ErrorFlag({ messageId, onRecheck, isRechecking }: ErrorFlagProps) {
  const [open, setOpen] = useState(false);
  const [errorDescription, setErrorDescription] = useState("");
  const [flagged, setFlagged] = useState(false);

  const handleSubmit = () => {
    if (errorDescription.trim()) {
      setFlagged(true);
      onRecheck(messageId, errorDescription);
      setOpen(false);
      setErrorDescription("");
    }
  };

  if (isRechecking) {
    return (
      <div className="flex items-center gap-2 text-sm text-blue-600 mt-2">
        <RefreshCw className="size-4 animate-spin" />
        <span>Rechecking...</span>
      </div>
    );
  }

  if (flagged) {
    return (
      <div className="flex items-center gap-2 text-sm text-green-600 mt-2">
        <CheckCircle className="size-4" />
        <span>Flagged for review</span>
      </div>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="mt-2 text-gray-500 hover:text-red-600"
        >
          <Flag className="size-4 mr-2" />
          Report Error
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Report Error</DialogTitle>
          <DialogDescription>
            Describe what's wrong with this response. Our system will automatically recheck and provide an improved summary.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="error-description">What's the issue?</Label>
            <Textarea
              id="error-description"
              placeholder="e.g., The table extraction is incomplete, missing columns, incorrect data..."
              value={errorDescription}
              onChange={(e) => setErrorDescription(e.target.value)}
              className="min-h-[100px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!errorDescription.trim()}
          >
            Submit & Recheck
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
