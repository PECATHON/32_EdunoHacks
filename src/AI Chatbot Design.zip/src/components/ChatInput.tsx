import { useState, useRef } from "react";
import { Send, Paperclip } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { BatchUpload, BatchFile } from "./BatchUpload";

interface ChatInputProps {
  onSendMessage: (text: string, file: File | null, files?: File[]) => void;
  disabled?: boolean;
}

export function ChatInput({ onSendMessage, disabled }: ChatInputProps) {
  const [message, setMessage] = useState("");
  const [batchFiles, setBatchFiles] = useState<BatchFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((message.trim() || batchFiles.length > 0) && !disabled) {
      const files = batchFiles.map(bf => bf.file);
      onSendMessage(message, files.length === 1 ? files[0] : null, files.length > 1 ? files : undefined);
      setMessage("");
      setBatchFiles([]);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      const newBatchFiles: BatchFile[] = files.map(file => ({
        id: `${Date.now()}-${Math.random()}`,
        file,
        status: "pending",
        progress: 0,
      }));
      setBatchFiles(prev => [...prev, ...newBatchFiles]);
    }
    e.target.value = "";
  };

  const handleRemoveFile = (id: string) => {
    setBatchFiles(prev => prev.filter(bf => bf.id !== id));
  };

  return (
    <form onSubmit={handleSubmit} className="border-t border-border bg-white dark:bg-gray-900 sunset:bg-[oklch(0.18_0.06_245)] p-4">
      <BatchUpload files={batchFiles} onRemoveFile={handleRemoveFile} />
      <div className="flex gap-2">
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          accept="image/*,.pdf,.doc,.docx,.txt,.csv"
          multiple
          onChange={handleFileSelect}
        />
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled}
        >
          <Paperclip className="size-5" />
        </Button>
        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Type your message or upload files (multiple supported)..."
          className="min-h-[60px] resize-none"
          disabled={disabled}
        />
        <Button
          type="submit"
          size="icon"
          disabled={(!message.trim() && batchFiles.length === 0) || disabled}
          className="h-[60px]"
        >
          <Send className="size-5" />
        </Button>
      </div>
    </form>
  );
}