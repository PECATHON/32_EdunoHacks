import { X, FileText, Image as ImageIcon, FileType } from "lucide-react";
import { Button } from "./ui/button";

interface FileUploadProps {
  file: File | null;
  onFileSelect: (file: File | null) => void;
}

export function FileUpload({ file, onFileSelect }: FileUploadProps) {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      onFileSelect(selectedFile);
    }
  };

  const removeFile = () => {
    onFileSelect(null);
  };

  const getFileIcon = () => {
    if (!file) return null;

    if (file.type.startsWith("image/")) {
      return <ImageIcon className="size-4" />;
    } else if (file.type === "application/pdf") {
      return <FileType className="size-4" />;
    } else {
      return <FileText className="size-4" />;
    }
  };

  if (!file) return null;

  return (
    <div className="mb-2 p-3 bg-gray-100 rounded-lg flex items-center justify-between">
      <div className="flex items-center gap-2 flex-1 min-w-0">
        {file.type.startsWith("image/") ? (
          <img
            src={URL.createObjectURL(file)}
            alt={file.name}
            className="h-12 w-12 rounded object-cover"
          />
        ) : (
          <div className="h-12 w-12 rounded bg-gray-200 flex items-center justify-center">
            {getFileIcon()}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <p className="truncate">{file.name}</p>
          <p className="text-xs text-gray-500">
            {(file.size / 1024).toFixed(1)} KB
          </p>
        </div>
      </div>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={removeFile}
        className="ml-2"
      >
        <X className="size-4" />
      </Button>
    </div>
  );
}
