import { FileText, Image as ImageIcon, FileType } from "lucide-react";
import { TablePreview, TableData } from "./TablePreview";
import { ErrorFlag } from "./ErrorFlag";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

export interface Message {
  id: string;
  type: "user" | "ai";
  content: string;
  file?: {
    name: string;
    type: string;
    url?: string;
  };
  files?: Array<{
    name: string;
    type: string;
    url?: string;
  }>;
  tableData?: TableData;
  timestamp: Date;
  isRechecking?: boolean;
}

interface ChatMessageProps {
  message: Message;
  onRecheck?: (messageId: string, errorDescription: string) => void;
}

export function ChatMessage({ message, onRecheck }: ChatMessageProps) {
  const isUser = message.type === "user";

  const getFileIcon = () => {
    if (!message.file) return null;
    
    if (message.file.type.startsWith("image/")) {
      return <ImageIcon className="size-4" />;
    } else if (message.file.type === "application/pdf") {
      return <FileType className="size-4" />;
    } else {
      return <FileText className="size-4" />;
    }
  };

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} mb-4`}>
      <div className={`max-w-[70%] ${isUser ? "order-2" : "order-1"}`}>
        <div
          className={`rounded-2xl px-4 py-3 ${
            isUser
              ? "bg-blue-600 sunset:bg-gradient-to-r sunset:from-orange-500 sunset:to-pink-600 text-white"
              : "bg-gray-100 dark:bg-gray-800 sunset:bg-[oklch(0.2_0.06_245)] text-gray-900 dark:text-gray-100 sunset:text-[oklch(0.95_0.02_60)]"
          }`}
        >
          {message.file && (
            <div className="mb-2">
              {message.file.type.startsWith("image/") && message.file.url ? (
                <img
                  src={message.file.url}
                  alt={message.file.name}
                  className="rounded-lg max-h-48 w-full object-cover mb-2"
                />
              ) : (
                <div
                  className={`flex items-center gap-2 p-3 rounded-lg mb-2 ${
                    isUser ? "bg-blue-700 sunset:bg-orange-600" : "bg-white dark:bg-gray-700 sunset:bg-[oklch(0.25_0.08_240)]"
                  }`}
                >
                  {getFileIcon()}
                  <span className="truncate">{message.file.name}</span>
                </div>
              )}
            </div>
          )}
          {message.files && message.files.length > 0 && (
            <div className="mb-2 space-y-2">
              <p className="text-xs opacity-80">
                Batch: {message.files.length} files processed
              </p>
              <div className="flex flex-wrap gap-2">
                {message.files.map((file, index) => (
                  <div
                    key={index}
                    className={`text-xs px-2 py-1 rounded ${
                      isUser ? "bg-blue-700 sunset:bg-orange-600" : "bg-white dark:bg-gray-700 sunset:bg-[oklch(0.25_0.08_240)]"
                    }`}
                  >
                    {file.name}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Use Tabs for AI messages with table data */}
          {!isUser && message.tableData ? (
            <Tabs defaultValue="summary" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-3">
                <TabsTrigger value="summary">Summary</TabsTrigger>
                <TabsTrigger value="table">Extracted Table</TabsTrigger>
              </TabsList>
              <TabsContent value="summary" className="mt-0">
                <p className="whitespace-pre-wrap">{message.content}</p>
              </TabsContent>
              <TabsContent value="table" className="mt-0">
                <TablePreview data={message.tableData} fileName={message.file?.name} />
              </TabsContent>
            </Tabs>
          ) : (
            <p className="whitespace-pre-wrap">{message.content}</p>
          )}
        </div>
        <div className="flex items-center justify-between mt-1">
          <span className={`text-xs text-gray-500 dark:text-gray-400 sunset:text-[oklch(0.65_0.05_50)] ${isUser ? "order-2" : "order-1"}`}>
            {message.timestamp.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </span>
          {!isUser && onRecheck && (
            <ErrorFlag
              messageId={message.id}
              onRecheck={onRecheck}
              isRechecking={message.isRechecking}
            />
          )}
        </div>
      </div>
    </div>
  );
}