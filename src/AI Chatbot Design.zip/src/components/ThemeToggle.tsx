import { useEffect, useState } from "react";
import { Sun, Moon, Sunset } from "lucide-react";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

export type Theme = "light" | "dark" | "sunset";

export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>("light");

  useEffect(() => {
    // Check localStorage for saved theme
    const savedTheme = localStorage.getItem("theme") as Theme;
    if (savedTheme) {
      setTheme(savedTheme);
      applyTheme(savedTheme);
    }
  }, []);

  const applyTheme = (newTheme: Theme) => {
    const root = document.documentElement;
    
    // Remove all theme classes
    root.classList.remove("light", "dark", "sunset");
    
    // Add the new theme class
    root.classList.add(newTheme);
    
    // Save to localStorage
    localStorage.setItem("theme", newTheme);
  };

  const handleThemeChange = (newTheme: Theme) => {
    setTheme(newTheme);
    applyTheme(newTheme);
  };

  const getIcon = () => {
    switch (theme) {
      case "dark":
        return <Moon className="size-5" />;
      case "sunset":
        return <Sunset className="size-5" />;
      default:
        return <Sun className="size-5" />;
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon">
          {getIcon()}
          <span className="sr-only">Toggle theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => handleThemeChange("light")}>
          <Sun className="size-4 mr-2" />
          Aurora Drift
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleThemeChange("dark")}>
          <Moon className="size-4 mr-2" />
          Obsidian Eclipse
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleThemeChange("sunset")}>
          <Sunset className="size-4 mr-2" />
          Saffron Duskwave
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}