import { useEffect, useState } from "react";
import { Clock } from "lucide-react";

interface LoadingTimerProps {
  startTime: Date;
}

export function LoadingTimer({ startTime }: LoadingTimerProps) {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const diff = Math.floor((now.getTime() - startTime.getTime()) / 1000);
      setElapsed(diff);
    }, 100);

    return () => clearInterval(interval);
  }, [startTime]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 sunset:text-[oklch(0.65_0.05_50)]">
      <Clock className="size-4" />
      <span>Processing: {formatTime(elapsed)}</span>
    </div>
  );
}