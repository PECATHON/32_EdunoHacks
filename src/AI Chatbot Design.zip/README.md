
  # AI Chatbot Design

  This is a code bundle for AI Chatbot Design. The original project is available at https://www.figma.com/design/3DzmuyIEB5ql5NmObQX2Zp/AI-Chatbot-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  